This is a panic buying tool that was written in Python. 

How to use it?
First, install Google Chrome.
Second, run it as an administrator.
Fourth, input the main URL. For example, https://www.taobao.com/
Fifth, input the goods URL, for example, https://item.jd.com/100028310790.html
Sixth, input the start time.

PS:
1-If you see the system warning, press "yes."
2-If you see the firewall warning, click all the ticks and press "allow."
3-If you find some questions when using this tool, please contact me at "lyf686@stu.xhsysu.edu.cn".